Public Class Form6

  Private Sub Form4_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    Me.Label1.Text = "Open"
    Me.Label2.Text = "Select"
    Me.Button1.Text = "Form1"
    Me.Button2.Text = "Form2"
    Me.Button3.Text = "Form3"
    Me.Button4.Text = "Form4"
    Me.Button5.Text = "Form5"
    Me.Button6.Text = "Form1"
    Me.Button7.Text = "Form2"
    Me.Button8.Text = "Form3"
    Me.Button9.Text = "Form4"
    Me.Button10.Text = "Form5"

  End Sub

  Private Sub Button1_Click(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles Button1.Click

    My.Forms.Form1.Show()

    My.Forms.Form1.Left = Me.Left + Me.Width + Me.Width * 0.1
    My.Forms.Form1.Top = Me.Top

  End Sub

  Private Sub Button2_Click(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles Button2.Click

    My.Forms.Form2.Show()

    My.Forms.Form2.Left = Me.Left + Me.Width + Me.Width * 0.1
    My.Forms.Form2.Top = Me.Top

  End Sub

  Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click

    My.Forms.Form3.Show()
    My.Forms.Form3.Left = Me.Left + Me.Width + Me.Width * 0.1

    My.Forms.Form3.Top = Me.Top

  End Sub

  Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click

    My.Forms.Form4.Show()
    My.Forms.Form4.Left = Me.Left + Me.Width + Me.Width * 0.1

    My.Forms.Form4.Top = Me.Top

  End Sub

  Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click

    My.Forms.Form5.Show()
    My.Forms.Form5.Left = Me.Left + Me.Width + Me.Width * 0.1

    My.Forms.Form5.Top = Me.Top

  End Sub

  Private Sub Button6_Click(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles Button6.Click

    My.Forms.Form1.Select()

  End Sub

  Private Sub Button7_Click(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles Button7.Click

    My.Forms.Form2.Select()

  End Sub

  Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click

    My.Forms.Form3.Select()

  End Sub

  Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click

    My.Forms.Form4.Select()

  End Sub

  Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click

    My.Forms.Form5.Select()

  End Sub

End Class