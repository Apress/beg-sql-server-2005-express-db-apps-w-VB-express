Public Class Form2

  Private Sub Button1_Click(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles Button1.Click
    Me.TextBox3.Text = CDbl(Me.TextBox1.Text) + CDbl(Me.TextBox2.Text)
  End Sub

  Private Sub Button2_Click(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles Button2.Click
    Me.TextBox3.Text = CDbl(Me.TextBox1.Text) - CDbl(Me.TextBox2.Text)
  End Sub

  Private Sub Button3_Click(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles Button3.Click
    Me.TextBox3.Text = CDbl(Me.TextBox1.Text) / CDbl(Me.TextBox2.Text)
  End Sub

  Private Sub Button4_Click(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles Button4.Click
    Me.TextBox3.Text = CDbl(Me.TextBox1.Text) * CDbl(Me.TextBox2.Text)
  End Sub

End Class