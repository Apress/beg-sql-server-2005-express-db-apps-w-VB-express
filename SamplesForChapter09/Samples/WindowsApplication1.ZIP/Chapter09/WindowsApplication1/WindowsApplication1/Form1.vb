'Option Strict On
Public Class Form1

  Dim var1

  Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
    Dim varString As String
    Const eAsChar As Char = "e"c

    'Insert a Char literal to a String variable
    varString = "H"c
    MessageBox.Show(varString)

    'Append a Char constant to a String variable
    varString &= eAsChar
    MessageBox.Show(varString)

    'Append a String literal to a String variable
    varString &= "llo"
    MessageBox.Show(varString)

  End Sub

  Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
    Dim str1, str2 As String, sbd1, _
        sbd2 As New System.Text.StringBuilder

    str1 = "Rick"
    str2 = str1

    MessageBox.Show("str1: " & str1 & ControlChars.Cr & _
      "str2: " & str2)

    str1 = String.Concat(str1, "y")

    MessageBox.Show("str1: " & str1 & ControlChars.Cr & _
      "str2: " & str2)

    sbd1.Insert(0, "Rick")
    sbd2 = sbd1

    MessageBox.Show("sbd1: " & sbd1.ToString & ControlChars.Cr & _
      "sbd2: " & sbd2.ToString)

    sbd1.Append("y")

    MessageBox.Show("sbd1: " & sbd1.ToString & ControlChars.Cr & _
      "sbd2: " & sbd2.ToString)

  End Sub

  Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
    Dim varShort As Short, varUShort As UShort, varBool As Boolean

    varShort = Short.MaxValue
    MessageBox.Show(varShort)

    varUShort = varShort * 2
    varBool = (varUShort = UShort.MaxValue)
    MessageBox.Show(varUShort & ControlChars.Cr & _
      "Is it maximum UShort value: " & varBool)

    varUShort += 1
    varBool = (varUShort = UShort.MaxValue)
    MessageBox.Show(varUShort & ControlChars.Cr & _
      "Is it maximum UShort value: " & varBool)

  End Sub

  Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
    Dim varDec As Decimal, varDec1 As Decimal = Long.MaxValue

    varDec = Long.MaxValue
    varDec += 1
    MessageBox.Show(varDec)

    varDec = 1 + varDec1
    MessageBox.Show(varDec)

  End Sub

  Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
    Dim dat1, dat2 As Date, ts1 As TimeSpan

    dat1 = Today

    MessageBox.Show("The full long date is " & _
      FormatDateTime(dat1, DateFormat.LongDate))
    MessageBox.Show("Just the day name is " & _
      dat1.ToString("dddd"))

    'Add 8 hours to dat1; compute ts1 as difference 
    'between dat2 And dat1
    dat2 = dat1.AddHours(8)
    ts1 = dat2.Subtract(dat1)

    'Display a TimeSpan value
    MessageBox.Show( _
      "The interval between the start of today, " & _
      ControlChars.Cr & _
      "and eight hours from the start of today is: " & _
      ts1.ToString)

  End Sub

End Class
