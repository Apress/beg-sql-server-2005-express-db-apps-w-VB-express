Public Class Form5
 Dim initComboBox1 As Boolean

 Private Sub Form5_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
  Dim intWidth As Integer

  Me.Button1.Text = "Fill Combo"
  Me.Button2.Text = "Read File"
  Me.Label1.Text = "Fill ListBox"

  Me.Width = 450
  intWidth = Me.ClientRectangle.Width
  Me.ComboBox1.Left = intWidth * 0.02
  Me.ComboBox1.Width = intWidth * 0.96
  Me.ListBox1.Width = Me.ComboBox1.Width - _
    Me.ListBox1.Left + (Me.Width - intWidth)

 End Sub

 Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

  Dim strFolderName As String = My.Application.Info.DirectoryPath, _
    topFolder As String = "C:\"
  'Can use a more specific topFolder value, such as the following one,
  'if it is known
  'topFolder As String = "C:\ProSSEApps\Chapter09"

  Do
   Me.ComboBox1.Items.Add(strFolderName)
   strFolderName = _
     My.Computer.FileSystem.GetParentPath(strFolderName)
  Loop Until strFolderName = topFolder

  initComboBox1 = True
  Me.ComboBox1.SelectedIndex = 0

 End Sub

 Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged

  If initComboBox1 = True Then
   initComboBox1 = False
  Else
   Me.ListBox1.Items.Clear()
   For Each foundFile As String In _
     My.Computer.FileSystem.GetFiles(Me.ComboBox1.SelectedItem)
    Me.ListBox1.Items.Add( _
      Microsoft.VisualBasic.Right(foundFile, _
      Len(foundFile) - Len(Me.ComboBox1.SelectedItem) - 1))
   Next
  End If

 End Sub

 Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged
  Dim fileReader As String, strPathFile As String

  strPathFile = My.Computer.FileSystem.CombinePath( _
    Me.ComboBox1.SelectedItem, Me.ListBox1.SelectedItem)
        fileReader = My.Computer.FileSystem.ReadAllText(strPathFile)
        'Debug.Write(fileReader)
  Console.WriteLine(fileReader)

 End Sub

 Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
  Dim strPathFile As String = "c:\ProSSEApps\Chapter09\" & _
    "SalesByPersonTerritoryRegion.rpt"
  Dim SalesWidths() As Integer = {15, 15, 14, 10, 18, 22, -1}
  Dim maxColWidths() As Integer = {15, 15, 14, 10, 18, 22, 21}

  Using Reader As New Microsoft.VisualBasic.FileIO. _
    TextFieldParser(strPathFile)
   Reader.TextFieldType = _
   Microsoft.VisualBasic.FileIO.FieldType.FixedWidth
   Reader.SetFieldWidths(SalesWidths)
   Dim currentRow As String()
   Dim int1 As Integer
   Do
    Try
     currentRow = Reader.ReadFields()
     Dim currentField As String
     For Each currentField In currentRow
      Console.Write(currentField & _
        StrDup((maxColWidths(int1) - currentField.Length), " "))
      int1 += 1
     Next
     int1 = 0
    Catch ex1 As _
    Microsoft.VisualBasic.FileIO.MalformedLineException _
    When Reader.EndOfData = True
     Exit Do
    Catch ex1 As _
    Microsoft.VisualBasic.FileIO.MalformedLineException _
    When Reader.EndOfData = False
     Debug.Print("Line " & ex1.Message & _
     "is not valid and will be skipped.")
    Finally
                    Console.WriteLine(ControlChars.Cr)
    End Try
   Loop
  End Using

 End Sub

End Class