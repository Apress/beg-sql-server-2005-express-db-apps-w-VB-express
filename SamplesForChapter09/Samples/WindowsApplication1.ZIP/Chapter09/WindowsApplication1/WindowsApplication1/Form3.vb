Public Class Form3
  Dim ErrMsg As String

  Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
    Dim int1, int2 As Integer

    Try
      int1 = Integer.Parse(Me.TextBox1.Text)
    Catch ex1 As Exception
      Me.TextBox3.Text = "Fix number 1"
      Exit Sub
    End Try

    Try
      int2 = Integer.Parse(Me.TextBox2.Text)
    Catch ex1 As Exception
      Me.TextBox3.Text = "Fix number 2"
      Exit Sub
    End Try

    Me.TextBox3.Text = int1 + int2

  End Sub

  Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
    Dim dbl1, dbl2 As Double

    dbl1 = StrToDbl(Me.TextBox1.Text)
    If ErrMsg <> "" Then
      Me.TextBox3.Text = "Fix number 1"
      Exit Sub
    End If

    dbl2 = StrToDbl(Me.TextBox2.Text)
    If ErrMsg <> "" Then
      Me.TextBox3.Text = "Fix number 2"
      Exit Sub
    End If

    Me.TextBox3.Text = dbl1 + dbl2

  End Sub

  Function StrToDbl(ByVal str1 As String) As Double
    Dim dbl1 As Double

    ErrMsg = ""

    Try
      dbl1 = Double.Parse(str1)
      Return dbl1
    Catch ex1 As FormatException
      ErrMsg = "Invalid double"
    Catch ex1 As Exception
      ErrMsg = "Not known"
    End Try

  End Function

  Function StrToInt(ByVal str1 As String) As Integer
    Dim int1 As Integer

    ErrMsg = ""
    Try
      int1 = Integer.Parse(str1)
      Return int1
    Catch ex1 As FormatException
      ErrMsg = "Invalid integer"
    Catch ex1 As Exception
      ErrMsg = "Not known"
    End Try

  End Function

  Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
    Dim int1, int2 As Integer, dbl1, dbl2 As Double

    int1 = StrToInt(Me.TextBox1.Text)
    If ErrMsg = "" Then
      int2 = StrToInt(Me.TextBox2.Text)
      If ErrMsg = "" Then
        Try
          'Test Throw statement to simulate an error
          'Throw New Exception("Test exception")
          Me.TextBox3.Text = int1 + int2 & " Int"
          Exit Sub
        Catch ex1 As Exception
          Debug.WriteLine(ex1.ToString)
          If InStr(ex1.ToString, "Overflow") <> 0 Then
            Exit Try
          Else
            Me.TextBox3.Text = "Immediate window"
            Exit Sub
          End If
        End Try
      End If
    End If

    dbl1 = StrToDbl(Me.TextBox1.Text)
    If ErrMsg <> "" Then
      Me.TextBox3.Text = "Fix number 1"
      Exit Sub
    End If

    dbl2 = StrToDbl(Me.TextBox2.Text)
    If ErrMsg <> "" Then
      Me.TextBox3.Text = "Fix number 2"
      Exit Sub
    End If

    Me.TextBox3.Text = dbl1 + dbl2 & " Dbl"

  End Sub

End Class