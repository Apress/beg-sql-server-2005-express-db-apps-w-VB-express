Public Class Form4

  ' Declare and initialize a one-dimensional array.
  Dim oneDimArray() As Char = {"X"c, "Y"c, "Z"c}

  ' Declare and initialize a two-dimensional array.
  Dim twoDimArray(,) As Double = {{5.8, 6.6}, {7.4, 8.2}}

  ' Declare and initialize a jagged array.
  Dim jaggedArray()() As Integer = {New Integer() {1, 2}, New Integer() {3, 4}}

  Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

    For Each oneControl As Control In Me.Controls
      ' Add code here to handle each item.
    Next

    For Each chr1 As Char In oneDimArray
      Me.ListBox1.Items.Add(chr1)
    Next


    For index As Integer = 1 To 10
      ' Add code to be executed on each iteration.
    Next

    For int1 As Integer = 0 To oneDimArray.GetUpperBound(0)
      Me.ListBox1.Items.Add("index = " & int1 & _
      ", value = " & oneDimArray(int1))
    Next


  End Sub

  Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

    For index As Integer = 1 To 10

      For index1 As Integer = 1 To 10
        ' Add code to be executed on each iteration.
      Next
      ' Add code to be executed on each iteration.
    Next

    Dim rsum As Double, rvals As String = ""
    For int1 As Integer = 0 To twoDimArray.GetUpperBound(0)
      For int2 As Integer = 0 To twoDimArray.GetUpperBound(1)
        rsum += twoDimArray(int1, int2)
        rvals &= twoDimArray(int1, int2) & ", "
      Next
      rvals = Microsoft.VisualBasic.Left( _
        rvals, rvals.Length - 2)
      Me.ListBox1.Items.Add("values for row " & _
        int1 & ": " & rvals & " sum to " & rsum)
      rvals = ""
      rsum = 0
    Next

  End Sub

  Private Sub Form4_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    Me.Button1.Text = "oneDimArray"
    Me.Button2.Text = "twoDimArray"
    Me.ListBox1.Width = Me.Button2.Right - Me.Button1.Left + 50
    Me.ListBox1.Left = Me.Button1.Left - 25
    Me.ListBox1.TopIndex = Me.Button1.Top + Me.Button1.Height + 6
  End Sub
End Class