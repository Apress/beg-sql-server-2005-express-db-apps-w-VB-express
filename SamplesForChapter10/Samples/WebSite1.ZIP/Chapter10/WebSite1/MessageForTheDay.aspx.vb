
Partial Class MessageForTheDay
    Inherits System.Web.UI.Page
    Dim Verses(30) As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.Title = "Message for the day"
    End Sub

    Protected Sub form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles form1.Load

        'Assign array members
        Me.Verses(0) = _
            "Whatsoever things are true, whatsoever things are honest, " & _
            "whatsoever things are just ... think about such things. " & _
            "Philippians 4:8"
        Me.Verses(1) = _
            "...whosoever believeth in Him should not perish, " & _
            "but have eternal life. John 3:15"
        Me.Verses(2) = "...being justified by faith we have peace with God through our Lord Jesus Christ. Romans 5:1"
        Me.Verses(3) = "... forgive ... that your Father in heaven forgive your trespasses. Mark 11:25"
        Me.Verses(4) = "Every place that the sole of your foot shall tread ... I have given unto you. Joshua 1:3"
        Me.Verses(5) = "The fruit of the Spirit is love, joy, peace, ... faith ... temperance; against such there is no law. Galatians 5:22-23"
        Me.Verses(6) = "... love one another as I have loved you ... John 13:34"
        Me.Verses(7) = "... faith is the substance of things hoped for, the evidence of things not seen. Hebrews 11:1"
        Me.Verses(8) = "... come boldly unto the throne of grace ... obtain mercy, and find grace ... Hebrews 4:16"
        Me.Verses(9) = "And He ... rebuked the wind, and said unto the sea, Peace be still.  And the wind ceased, and there was a great calm.  Mark 4:39"
        Me.Verses(10) = "Glory and honour are in His pressence; strength and gladness are in His place. 1 Chronicles 16:27"
        Me.Verses(11) = "... greater is He that is in you, than he that is in the world.  1 John 4:4"
        Me.Verses(12) = "he that believeth on Me, the works that I do shall he do also; and greater works than these he shall do also... John 14:12"
        Me.Verses(13) = "If we confess our sins, He is faithful and just to forgive our sins and to cleanse us from all unrighteousness.  1 John 1:9"
        Me.Verses(14) = "Blessed are the merciful: for they shall obtain mercy.  Matthew 5:7"
        Me.Verses(15) = "For thou, Lord, wilt bless the righteous; with favour wilt thou compass him as with a shield.  Psalm 5:12"
        Me.Verses(16) = "I have set before you life and death, blessing and cursing: therefore choose life, that thou and thy seed may live ... Deuteronomy 30:19"
        Me.Verses(17) = "... by whose stripes we were healed ... ye were sheep going astray; but are now returned unto the Shepherd and Bishop of your souls.  1 Peter 2:24-25"
        Me.Verses(18) = "Many are the afflictions of the righteous, but the Lord delivereth him out of them all. Psalm 34:19"
        Me.Verses(19) = "... I am come that they may have life, and that they might have it more abundantly.  John 10:10"
        Me.Verses(20) = "The blessing of the Lord, it maketh rich,and He addeth no sorrow with it.  Proverbs 10:22"
        Me.Verses(21) = "For we walk by faith, not by sight ...  2 Corinthians 5:7"
        Me.Verses(22) = "Surely goodness and mercy shall follow me all the days of my life ... Psalm 23:6"
        Me.Verses(23) = "But my God shall suplly all your need according to his riches in glory by Christ Jesus. Philippians 4:19"
        Me.Verses(24) = "Thou wilt keep him in perfect peace, whose mind is stayed on Thee: because he trusteth in Thee.  Isaiah 26:3"
        Me.Verses(25) = "Trust in the Lord with all thine heart; and lean not to thine own understanding. Proverb 3:5"
        Me.Verses(26) = "For ye are bought with a price: therefore glorify God in your body, and in your spirit, which are God's. 1 Corinthians 6:20"
        Me.Verses(27) = "For God has not given us the the spirit of fear; but of power, and of love, and of a sound mind.  2 Timothy 1:7"
        Me.Verses(28) = "And now abideth faith, hope, and charity ... but the greatest of these is charity.  1 Corinthians 13:13"
        Me.Verses(29) = _
            "For my son was dead, and is alive again; he was lost, " & _
            "and is found.  And they began to be merry. Luke 15:24"
        Me.Verses(30) = _
            "For God sent not his Son into the world to condemn the world; " & _
            "but that the world through Him might be saved. John 3:17"

    End Sub

    Protected Sub Calendar1_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Calendar1.SelectionChanged
        Me.Label3.Text = Verses(Me.Calendar1.SelectedDate.Day - 1)
    End Sub
End Class
