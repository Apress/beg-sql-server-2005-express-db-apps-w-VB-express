
Partial Class CalendarFormattedDate
    Inherits System.Web.UI.Page

    Protected Sub Calendar1_SelectionChanged(ByVal sender As Object, _
        ByVal e As System.EventArgs) Handles Calendar1.SelectionChanged
        Me.Label1.Text = "Unformatted date: " & _
            Me.Calendar1.SelectedDate.ToString
        Me.Label2.Text = "Formatted date: " & _
        Me.Calendar1.SelectedDate.ToString("d")
    End Sub
End Class
