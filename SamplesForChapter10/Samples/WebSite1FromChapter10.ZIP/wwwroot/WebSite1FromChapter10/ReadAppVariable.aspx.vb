
Partial Class ReadAppVariable
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Me.Button1.Text = "All Sales Persons"
        Me.Button2.Text = "SalesPersonID"
        Me.Label1.Text = "SalesPersonID"
        Me.Title = "Reading an Application Variable"

    End Sub



    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click

        Dim str1 As String = Application("SQLrpt").ToString

        Response.Write(str1)

    End Sub


    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click

        Dim str1 As String = Application("SQLrpt").ToString

        Dim intStart As Integer = InStr(str1, _
            "SalesPersonID, " & Me.TextBox1.Text) - 3
        Dim intEnd As Integer = InStr(InStr(str1, _
            "SalesPersonID, " & Me.TextBox1.Text), str1, "<br \>")
        Dim int3 As Integer = InStr(intEnd, str1, ",")
        Dim intBeg As Integer = 1
        Dim strStart As String = Mid(str1, intEnd + 6, int3 - _
            (intEnd + 6) + 1)

        intEnd = 1
        For intLoop As Integer = 1 To 7
            intStart = InStr(intEnd, str1, strStart)
            intEnd = InStr(InStr(intStart, _
                str1, strStart), str1, "<br \>")
            Response.Write( _
                Mid(str1, intStart, intEnd - intStart + 6))
        Next intLoop

    End Sub
End Class
