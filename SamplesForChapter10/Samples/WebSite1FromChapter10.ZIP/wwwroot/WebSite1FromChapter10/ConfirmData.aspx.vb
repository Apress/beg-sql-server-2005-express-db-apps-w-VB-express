
Partial Class ConfirmData
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Me.Title = "Confirm Data Form"
        Me.Button1.Text = "OK"
        Me.Button2.Text = "Edit"

        Me.Label1.Text = "First name: " & Session("Fname").ToString
        Me.Label2.Text = "Last name : " & Session("Lname").ToString
        Me.Label3.Text = "Email addr: " & Session("Eaddr").ToString

    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim strGBPathFile As String = _
           My.Computer.FileSystem. _
               CombinePath(Server.MapPath("/WebSite1FromChapter10/App_Data"), _
               "GuestBook.txt")

        My.Computer.FileSystem.WriteAllText _
            (strGBPathFile, "Fname: " & _
            Session("Fname").ToString & ControlChars.Cr, True)
        My.Computer.FileSystem.WriteAllText _
            (strGBPathFile, "Lname: " & _
            Session("Lname").ToString & ControlChars.Cr, True)
        My.Computer.FileSystem.WriteAllText _
            (strGBPathFile, "Eaddr: " & _
            Session("Eaddr").ToString & ControlChars.Cr, True)

        My.Response.Redirect("Thankyou.htm")
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        My.Response.Redirect("GuestBook.aspx?fromconfirm=yes")
    End Sub
End Class
