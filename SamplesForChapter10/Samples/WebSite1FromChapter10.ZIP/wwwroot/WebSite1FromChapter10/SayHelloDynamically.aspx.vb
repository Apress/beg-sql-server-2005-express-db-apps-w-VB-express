
Partial Class SayHelloDynamically
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            With Me.Label2
                .Visible = True
                .Text = "Hello " & Me.TextBox1.Text & "!"
            End With
            Me.HyperLink1.Visible = True
            Me.Label1.Visible = False
            Me.TextBox1.Visible = False
            Me.Button1.Visible = False
        Else
            Me.Label1.Text = "Enter name:"
            Me.Button1.Text = "Click me"
            With Me.HyperLink1
                .Visible = False
                .Text = _
                "Go to OnePage.htm that links to AnotherPage.htm"
                .NavigateUrl = "OnePage.htm"
            End With
            Me.Label2.Visible = False
            With Me.RequiredFieldValidator1
                .ControlToValidate = "TextBox1"
                .Display = ValidatorDisplay.Dynamic
                .ErrorMessage = "Enter name and click button twice."
            End With
        End If
    End Sub
End Class
