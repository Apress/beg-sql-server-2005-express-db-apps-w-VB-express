
Partial Class GuestBook
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Me.Title = "Guest Book Data Form"
        Me.Label1.Text = "First name:"
        Me.Label2.Text = "Last name :"
        Me.Label3.Text = "Email addr:"
        Me.Label1.Font.Name = "Courier New"
        Me.Label2.Font.Name = "Courier New"
        Me.Label3.Font.Name = "Courier New"
        Me.TextBox1.Width = 230
        Me.TextBox2.Width = 230
        Me.TextBox3.Width = 230
        Me.Button1.Text = "Submit"

        If Request.QueryString.Count > 0 Then
            If Page.IsPostBack = False And _
                Request.QueryString(0) = "yes" Then
                Me.TextBox1.Text = Session("Fname").ToString
                Me.TextBox2.Text = Session("Lname").ToString
                Me.TextBox3.Text = Session("Eaddr").ToString
            End If
        End If

    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click

        Session("Fname") = Me.TextBox1.Text
        Session("Lname") = Me.TextBox2.Text
        Session("Eaddr") = Me.TextBox3.Text

        Me.TextBox1.Text = ""
        Me.TextBox2.Text = ""
        Me.TextBox3.Text = ""

        My.Response.Redirect("ConfirmData.aspx")

    End Sub
End Class
