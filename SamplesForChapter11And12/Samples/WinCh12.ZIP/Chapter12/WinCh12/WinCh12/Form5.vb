Imports System.Data
Imports System.Data.SqlClient
Public Class Form5

 Dim cnn1 As SqlConnection = _
   New System.Data.SqlClient.SqlConnection( _
   "Data Source=.\sqlexpress;" & _
   "Integrated Security=True;" & _
   "Initial Catalog=AdventureWorks")
 Dim das1 As DataSet


 Private Sub Form5_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

  Me.Button1.Text = "Show contents"
  Me.Button1.Width = CInt(1.25 * Me.Button1.Width)

  Me.GroupBox1.Text = "Sort by:"
  Me.GroupBox1.Width = CInt(1.1 * Me.GroupBox1.Width)
  Me.RadioButton1.Text = "Alphabetical"
  Me.RadioButton2.Text = "ProducategoryID"
  Me.RadioButton1.Checked = True
  Me.Button2.Text = "Show values"
  Me.Button2.Width = CInt(1.25 * Me.Button2.Width)


  Me.Button3.Text = "Populate listboxes"
  Me.Button3.Width = CInt(1.5 * Me.Button3.Width)

  Me.Height = CInt(Me.Height * 1.1)

 End Sub

 Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

  'Specify query statements to populate DataTables in DataSet
  Dim strQuery1 As String = _
   "SELECT ProductCategoryID, Name " & _
   "FROM Production.ProductCategory"
  Dim strQuery2 As String = _
   "SELECT ProductCategoryID, " & _
   "ProductSubcategoryID, Name " & _
   "FROM Production.ProductSubcategory"

  das1 = TwoDTsInADS(strQuery1, strQuery2)

  'Demo the syntax for iterating through the DataTable objects
  'in a DataSet object
  Dim str1 As String = ""
  For Each dtb1 As DataTable In das1.Tables
   str1 += dtb1.TableName & ControlChars.Cr
  Next
  MessageBox.Show( _
   "The das1 dataset has " & das1.Tables.Count.ToString & _
   " table(s).  The table name(s) are:" & ControlChars.CrLf & str1)

  'Demo syntax for referring to the first cell in the first
  'row of the first DataTable object of the das1 DataSet object and
  'the last cell in the last table of the das1 DataSet object
  MsgBox("First cell in first row of first table:" & _
   ControlChars.CrLf & das1.Tables(0).Rows(0)(0).ToString & _
   ControlChars.CrLf & _
   "Last cell in last row of last table:" & _
   ControlChars.CrLf & _
   das1.Tables(das1.Tables.Count - 1).Rows(36)(2).ToString)

  'Sample syntax for referring to the last DataTable in
  'a dataset (int1), the last DataRow in the Rows collection
  'of a DataTable, and the last column in the Columns collection
  'of a DataTAble; remove the comments from the following four
  'lines to test the code
  'Dim int1 As Integer = das1.Tables.Count - 1
  'Dim int2 As Integer = das1.Tables(int1).Rows.Count - 1
  'Dim int3 As Integer = das1.Tables(int1).Columns.Count - 1
  'MessageBox.Show(int1.ToString & ", " & int2.ToString & ", " & int3.ToString)

  DisplayDTsInADS(das1)

 End Sub



 Friend Function TwoDTsInADS(ByVal strQuery1 As String, _
 ByVal strQuery2 As String) As DataSet

  'Declare and instantiate first DataAdapter object
  Dim dapCategories As SqlDataAdapter = _
  New SqlDataAdapter(strQuery1, cnn1)

  'Declare and instantiate second DataAdapter object
  Dim dapSubcategories As SqlDataAdapter = _
  New SqlDataAdapter(strQuery2, cnn1)

  'Instantiate the das1 DataSet
  das1 = New DataSet

  'Fill the das1 DataSet with two different DataAdapter objects
  dapCategories.Fill(das1, "ProductCategories")
  dapSubcategories.Fill(das1, "ProductSubcategories")

  Return das1

 End Function


 Friend Sub DisplayDTsInADS(ByVal das1 As DataSet)

  Dim str1 As String
  'Demo the syntax for iterating through all cell values in all
  'DataTable objects within the das1 DataSet object
  str1 = ""
  For Each dtb1 As DataTable In das1.Tables
   str1 += "Rows for " & dtb1.TableName & _
    Microsoft.VisualBasic.StrDup(2, ControlChars.CrLf)
   For Each drw1 As DataRow In das1.Tables(dtb1.TableName).Rows
    For Each dcl1 As DataColumn In _
     das1.Tables(dtb1.TableName).Columns
     str1 += drw1(dcl1.ColumnName).ToString & ", "
    Next
    str1 = Microsoft.VisualBasic.Left(str1, Len(str1) - 2)
    str1 += ControlChars.CrLf
   Next
   str1 += ControlChars.CrLf
  Next dtb1
  MessageBox.Show(str1)

 End Sub


 Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

  Dim strQuery1 As String = ""
  Dim strQuery2 As String = ""

  'Order DataTable rows by Name or ProductCategoryID
  'column values
  If Me.RadioButton1.Checked Then
   strQuery1 = _
    "SELECT ProductCategoryID, Name " & _
    "FROM Production.ProductCategory " & _
    "ORDER BY Name"
   strQuery2 = _
   "SELECT ProductCategoryID, " & _
   "ProductSubcategoryID, Name " & _
   "FROM Production.ProductSubcategory " & _
    "ORDER BY Name"
  Else
   strQuery1 = _
    "SELECT ProductCategoryID, Name " & _
    "FROM Production.ProductCategory " & _
    "ORDER BY ProductCategoryID"
   strQuery2 = _
   "SELECT ProductCategoryID, " & _
   "ProductSubcategoryID, Name " & _
   "FROM Production.ProductSubcategory " & _
    "ORDER BY ProductCategoryID"
  End If

  'Dim das1 As DataSet
  das1 = TwoDTsInADS(strQuery1, strQuery2)

  DisplayDTsInADS(das1)

 End Sub



 Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click

  'Populate the DataTables
  Dim strQuery1 As String = _
   "SELECT ProductCategoryID, Name " & _
   "FROM Production.ProductCategory"
  Dim strQuery2 As String = _
   "SELECT ProductCategoryID, " & _
   "ProductSubcategoryID, Name " & _
   "FROM Production.ProductSubcategory"
  das1 = TwoDTsInADS(strQuery1, strQuery2)

  'Display the Name column from the first DataTable
  Me.ListBox1.DataSource = das1.Tables(0)
  Me.ListBox1.DisplayMember = "Name"

 End Sub



 Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged

  'Whenever the index to ListBox1 changes,
  're-populate ListBox2
  Me.ListBox2.Items.Clear()
  For Each drw1 As DataRow In das1.Tables(1).Rows
   If CInt(drw1("ProductCategoryID")) = _
    CInt(das1.Tables(0).Rows( _
    Me.ListBox1.SelectedIndex)("ProductCategoryID")) Then
    Me.ListBox2.Items.Add(drw1("Name"))
   End If
  Next

 End Sub

End Class