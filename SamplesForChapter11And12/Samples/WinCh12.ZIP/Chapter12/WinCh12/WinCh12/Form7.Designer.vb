<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class Form7
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
  Me.Button4 = New System.Windows.Forms.Button
  Me.Button3 = New System.Windows.Forms.Button
  Me.Button2 = New System.Windows.Forms.Button
  Me.Button1 = New System.Windows.Forms.Button
  Me.SuspendLayout()
  '
  'Button4
  '
  Me.Button4.Location = New System.Drawing.Point(12, 99)
  Me.Button4.Name = "Button4"
  Me.Button4.Size = New System.Drawing.Size(75, 23)
  Me.Button4.TabIndex = 7
  Me.Button4.Text = "Button4"
  '
  'Button3
  '
  Me.Button3.Location = New System.Drawing.Point(12, 70)
  Me.Button3.Name = "Button3"
  Me.Button3.Size = New System.Drawing.Size(75, 23)
  Me.Button3.TabIndex = 6
  Me.Button3.Text = "Button3"
  '
  'Button2
  '
  Me.Button2.Location = New System.Drawing.Point(12, 41)
  Me.Button2.Name = "Button2"
  Me.Button2.Size = New System.Drawing.Size(75, 23)
  Me.Button2.TabIndex = 5
  Me.Button2.Text = "Button2"
  '
  'Button1
  '
  Me.Button1.Location = New System.Drawing.Point(12, 12)
  Me.Button1.Name = "Button1"
  Me.Button1.Size = New System.Drawing.Size(75, 23)
  Me.Button1.TabIndex = 4
  Me.Button1.Text = "Button1"
  '
  'Form7
  '
  Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
  Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
  Me.ClientSize = New System.Drawing.Size(292, 266)
  Me.Controls.Add(Me.Button4)
  Me.Controls.Add(Me.Button3)
  Me.Controls.Add(Me.Button2)
  Me.Controls.Add(Me.Button1)
  Me.Name = "Form7"
  Me.Text = "Form7"
  Me.ResumeLayout(False)

 End Sub
 Friend WithEvents Button4 As System.Windows.Forms.Button
 Friend WithEvents Button3 As System.Windows.Forms.Button
 Friend WithEvents Button2 As System.Windows.Forms.Button
 Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
