Imports System.Data.SqlClient
Public Class Form4

 Dim cnn1 As SqlConnection

 Private Sub Form4_Load(ByVal sender As Object, _
  ByVal e As System.EventArgs) Handles Me.Load

  'Compute top-level project folder and use it as a prefix for
  'the primary data file
  Dim int1 As Integer = _
   InStr(My.Application.Info.DirectoryPath, "bin\")
  Dim strPath As String = Microsoft.VisualBasic.Left( _
   My.Application.Info.DirectoryPath, int1 - 1)
  Dim pdbfph As String = strPath & "northwnd.mdf"
  Dim cst As String = "Data Source=.\sqlexpress;" & _
    "Integrated Security=SSPI;" & _
    "AttachDBFileName=" & pdbfph

  cnn1 = New SqlConnection(cst)

  Me.Button1.Text = "Create Table"
  Me.Button2.Text = "Insert"
  Me.Button3.Text = "Find"
  Me.Button4.Text = "Update"
  Me.Button5.Text = "Delete"
  Me.Button6.Text = "Drop Table"

  Me.GroupBox1.Text = "Add new contact"
  Me.GroupBox2.Text = "Modify/delete existing contact"

  Me.Label1.Text = "Name"
  Me.Label2.Text = "Email address"

  Me.Label3.Text = "ID number"
  Me.Label4.Text = "Name"
  Me.Label5.Text = "Email address"

  DisableEnableUpdateDeleteControls("Disable")

 End Sub

 Sub DisableEnableUpdateDeleteControls(ByVal str1 As String)

  If UCase(str1) = "DISABLE" Then
   Me.Label4.Enabled = False
   Me.Label5.Enabled = False
   Me.TextBox4.Enabled = False
   Me.TextBox5.Enabled = False
   Me.Button4.Enabled = False
   Me.Button5.Enabled = False
   Me.TextBox3.Clear()
   Me.TextBox4.Clear()
   Me.TextBox5.Clear()
  Else
   Me.Label4.Enabled = True
   Me.Label5.Enabled = True
   Me.TextBox4.Enabled = True
   Me.TextBox5.Enabled = True
   Me.Button4.Enabled = True
   Me.Button5.Enabled = True
  End If

 End Sub

 Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

  'Create a command to create a table
  Dim cmd1 As New SqlCommand
  cmd1.CommandText = "CREATE TABLE DotNetTable (" & _
    "ContactID int IDENTITY PRIMARY KEY, " & _
    "ContactName nvarchar(25) NOT NULL, " & _
    "ContactEAddr nvarchar(60) NOT NULL)"
  cmd1.Connection = cnn1

  'Invoke the command 
  Try
   cnn1.Open()
   cmd1.ExecuteNonQuery()
   MessageBox.Show("Command succeeded.", "Outcome", _
     MessageBoxButtons.OK, MessageBoxIcon.Information)
  Catch ex As Exception
   MessageBox.Show(ex.Message)
  Finally
   cnn1.Close()
  End Try

 End Sub

 Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

  Dim cmd1 As New SqlCommand

  'Computations for valid email address
  Dim int_at As Integer = InStr(Me.TextBox2.Text, "@")
  Dim int_period As Integer = InStr(int_at, Me.TextBox2.Text, ".")
  Dim int_len As Integer = Len(Me.TextBox2.Text)

  'Verfiy name and email and display reminder to fix if not valid;
  'otherwise, specify SqlCommand objet to enter a new row
  If InStr(Me.TextBox1.Text, ";") > 0 Or _
   InStr(Me.TextBox1.Text, "=") > 0 Or _
   (Len(Me.TextBox1.Text) = 0) Or _
   (Len(Me.TextBox1.Text) > 25) Then
   MessageBox.Show("Invalid Name.  Please fix name.")
   Exit Sub
  ElseIf Not (int_at > 0 And int_period > 0 And int_len >= 8) Then
   MessageBox.Show("Invalid email address.", "Please fix it")
   Exit Sub
  Else

   cmd1.CommandText = "INSERT DotNetTable " & _
     "(ContactName, ContactEAddr) VALUES " & _
     "('" & Me.TextBox1.Text & "', '" & Me.TextBox2.Text & "')"
   cmd1.Connection = cnn1
  End If

  'Invoke the ExecuteNonQuery method of the SqlCommand object,
  'and clear TextBox1 and TextBox2
  Try
   cnn1.Open()
   cmd1.ExecuteNonQuery()
   Me.TextBox1.Clear()
   Me.TextBox2.Clear()
  Catch ex As Exception
   MessageBox.Show(ex.Message)
  Finally
   cnn1.Close()
  End Try


 End Sub

 Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click

  Dim str1 As String = Me.TextBox3.Text
  Dim rdr1 As SqlDataReader
  'Dim int1 As Integer

  'Verify that an integer value is input and is in 
  'proper range of values
  If IsInteger(str1) = False Then
   MessageBox.Show("Please input an integer as an ID value.", _
     "Warning notice", MessageBoxButtons.OK, MessageBoxIcon.Warning)
   Exit Sub
  End If

  Dim strReturn As String = _
  Form2.InColRange(str1, "ContactID", _
  "DotNetTable", cnn1)

  Select Case strReturn
   Case "Value in range"
    'Define cmd1 and execute it
    Dim cmd1 As New SqlCommand( _
              "SELECT ContactName, ContactEAddr " & _
              "FROM DotNetTable Where ContactID = " & str1, _
              cnn1)
    rdr1 = cmd1.ExecuteReader()
    Try
     If rdr1.HasRows Then
      rdr1.Read()
      Me.TextBox4.Text = rdr1.GetString(0)
      Me.TextBox5.Text = rdr1.GetString(1)
      DisableEnableUpdateDeleteControls("Enable")
     Else
      MessageBox.Show("No contact corresponds to ID value.", _
      "Warning notice", MessageBoxButtons.OK, _
      MessageBoxIcon.Warning)
     End If
    Catch ex As Exception
     MessageBox.Show(ex.Message, "Error message", _
       MessageBoxButtons.OK, MessageBoxIcon.Error)
    Finally
     rdr1.Close()
     cnn1.Close()
    End Try
   Case "Value out of range"
    MessageBox.Show("Please enter another ID value.", _
      "Warning notice", MessageBoxButtons.OK, _
      MessageBoxIcon.Warning)
   Case Else
    MessageBox.Show(strReturn)
  End Select

 End Sub

 Function IsInteger(ByVal str1 As String) As Boolean
  Dim int1 As Integer

  Try
   int1 = CInt(str1)
   If CDbl(str1) = CInt(str1) Then
    Return True
   End If
  Catch ex As Exception
   Return False
  End Try

 End Function

 Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click

  Dim cmd1 As New SqlCommand

  'Computations for valid email address
  Dim int_at As Integer = InStr(Me.TextBox5.Text, "@")
  Dim int_period As Integer = InStr(int_at, Me.TextBox5.Text, ".")
  Dim int_len As Integer = Len(Me.TextBox5.Text)

  'Verfiy name and email and display reminder to fix if not valid;
  'otherwise, update existing row
  If InStr(Me.TextBox4.Text, ";") > 0 Or _
   InStr(Me.TextBox4.Text, "=") > 0 Or _
   (Len(Me.TextBox4.Text) = 0) Or _
   (Len(Me.TextBox4.Text) > 25) Then
   MessageBox.Show("Invalid Name.  Please fix name.")
   Exit Sub
  ElseIf Not (int_at > 0 And int_period > 0 And int_len >= 8) Then
   MessageBox.Show("Invalid email address.", "Please fix it")
   Exit Sub
  Else
   cmd1.CommandText = "UPDATE DotNetTable " & _
    "SET ContactName = '" & Me.TextBox4.Text & "', " & _
    "ContactEAddr = '" & Me.TextBox5.Text & "' " & _
    "WHERE ContactID = " & Me.TextBox3.Text
   cmd1.Connection = cnn1
  End If

  Try
   cnn1.Open()
   cmd1.ExecuteNonQuery()
  Catch ex As Exception
   MessageBox.Show(ex.Message)
  Finally
   cnn1.Close()
   DisableEnableUpdateDeleteControls("Disable")
  End Try


 End Sub

 Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click

  'Verify that an integer value is input and is in 
  'proper range of values
  Dim str1 As String = Me.TextBox3.Text
  If IsInteger(str1) = False Then
   MessageBox.Show("Please input an integer as an ID value.", _
     "Warning notice", MessageBoxButtons.OK, MessageBoxIcon.Warning)
   Exit Sub
  End If

  Dim strReturn As String = _
  Form2.InColRange(str1, "ContactID", _
  "DotNetTable", cnn1)


  'Create a command to delete a row
  Dim cmd1 As New SqlCommand
  cmd1.CommandText = "DELETE FROM DotNetTable " & _
    " WHERE ContactID = " & Me.TextBox3.Text
  cmd1.Connection = cnn1

  'Invoke the command 
  Try
   'cnn1.Open()
   cmd1.ExecuteNonQuery()
  Catch ex As Exception
   MessageBox.Show(ex.Message)
  Finally
   cnn1.Close()
   DisableEnableUpdateDeleteControls("Disable")
  End Try

 End Sub

 Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click

  'Create a command to drop a table
  Dim cmd1 As New SqlCommand
  cmd1.CommandText = "DROP TABLE DotNetTable"
  cmd1.Connection = cnn1

  'Invoke the command 
  Try
   cnn1.Open()
   cmd1.ExecuteNonQuery()
   MessageBox.Show("Command succeeded.", "Outcome", _
     MessageBoxButtons.OK, MessageBoxIcon.Information)
  Catch ex As Exception
   MessageBox.Show(ex.Message)
  Finally
   cnn1.Close()
  End Try
 End Sub

End Class