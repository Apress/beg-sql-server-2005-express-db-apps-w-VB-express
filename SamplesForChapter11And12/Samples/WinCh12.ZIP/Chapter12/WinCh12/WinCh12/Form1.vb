Imports System.Data.SqlClient
Imports System.Data.OleDb
Public Class Form1

  Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    Me.GroupBox1.Text = "Integrated Security"
    Me.GroupBox2.Text = "SQL Server Security"
    Me.GroupBox3.Text = "Open database files"

    Me.Button1.Text = "Login"
    Me.Button2.Text = "Login"
    Me.Button3.Text = "SSE Login"
    Me.Button4.Text = "Access Login"
    Me.TextBox2.PasswordChar = "*"c

    Me.Label1.Text = "User ID:"
    Me.Label2.Text = "Password:"

  End Sub

 Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

  Dim cnn1 As SqlConnection = _
    New SqlConnection("Data Source=(local);" & _
    "Integrated Security=True;" & _
    "Initial Catalog=northwind")

  'Open connection
  cnn1.Open()
  MessageBox.Show("Connection succeeded.")

  'Place code to use connection here

  'Close connection
  cnn1.Close()
  MessageBox.Show("Connection closed.")

 End Sub

 Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
  Dim cbd1 As New SqlConnectionStringBuilder()
  Dim cnn1 As New SqlConnection

  'Build connection string
  cbd1.DataSource = ".\sqlexpress"
  cbd1.InitialCatalog = "northwind"
  cbd1.UserID = Me.TextBox1.Text
  cbd1.Password = Me.TextBox2.Text

  'Assign connection string
  cnn1.ConnectionString = (cbd1.ConnectionString)

  'Open connection and always close it when done;
  'catch exceptions from attempt to connect
  Try
   cnn1.Open()
   MessageBox.Show("Connection succeeded.")
   'Insert code to use connection string here
  Catch ex As Exception
   MessageBox.Show(ex.Message, "something is wrong")
  Finally
   cnn1.Close()
   MessageBox.Show("Connection closed.")
  End Try

 End Sub

 Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click

  'Compute top-level project folder and use it as a prefix for
  'the primary data file
  Dim int1 As Integer = _
   InStr(My.Application.Info.DirectoryPath, "bin\")
  Dim strPath As String = _
   Microsoft.VisualBasic.Left( _
   My.Application.Info.DirectoryPath, int1 - 1)
  Dim pdbfph As String = strPath & "northwnd.mdf"

  'Then, assign the path to the primary data file as the
  'AttachDBFileName argument value in a connection string
  Dim cst As String = "Data Source=.\sqlexpress;" & _
    "Integrated Security=SSPI;" & _
    "AttachDBFileName=" & pdbfph
  Dim cnn1 As System.Data.SqlClient.SqlConnection = _
    New SqlConnection(cst)

  'Open and close the connection to a SQL Server
  'Express  database file
  Try
   cnn1.Open()
   MessageBox.Show("Connection succeeded.")
   'Insert code to use connection string here
  Catch ex As Exception
   MessageBox.Show(ex.Message, "something is wrong")
  Finally
   cnn1.Close()
   MessageBox.Show("Connection closed.")
  End Try

 End Sub

 Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
  Dim cnn1 As New OleDbConnection

  'Compute the path to an Access database inside the project
  Dim int1 As Integer = _
    InStr(My.Application.Info.DirectoryPath, "bin\")
  Dim DSPath As String = _
    Microsoft.VisualBasic.Left( _
    My.Application.Info.DirectoryPath, int1 - 1)
  DSPath += "Northwind.mdb"

  'Compose connection string and open connection
  'using the OleDb data provider
  cnn1.ConnectionString = "Provider = Microsoft.Jet.OLEDB.4.0;" & _
    "Data Source = " & DSPath
  Try
   cnn1.Open()
   MessageBox.Show("Connection succeeded.")
  Catch ex As Exception
   MessageBox.Show(ex.Message, "something is wrong")
  Finally
   cnn1.Close()
   MessageBox.Show("Connection closed.")
  End Try

 End Sub

End Class
