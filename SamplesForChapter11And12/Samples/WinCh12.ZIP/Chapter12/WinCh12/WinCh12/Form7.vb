Imports System.Data
Imports System.Data.SqlClient
Public Class Form7
 Dim cnn1 As SqlConnection = _
   New System.Data.SqlClient.SqlConnection( _
   "Data Source=.\sqlexpress;" & _
   "Integrated Security=True;" & _
   "Initial Catalog=AdventureWorks")

 Dim dap1 As SqlClient.SqlDataAdapter
 Dim dap2 As SqlClient.SqlDataAdapter
 Dim das1 As DataSet
 Dim int1, int2 As Integer

 Private Sub Form7_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

  'Create a command to drop a table
  Dim cmd1 As New SqlCommand
  cmd1.CommandText = "DROP TABLE DotNetTable"
  cmd1.Connection = cnn1

  'Invoke the command 
  Try
   cnn1.Open()
   cmd1.ExecuteNonQuery()
  Catch ex As Exception
   MessageBox.Show(ex.Message)
  Finally
   cnn1.Close()
  End Try

  'Create a command to create a table
  'Dim cmd1 As New SqlCommand
  cmd1.CommandText = "CREATE TABLE DotNetTable (" & _
    "ContactID int IDENTITY PRIMARY KEY, " & _
    "ContactName nvarchar(25) NOT NULL, " & _
    "ContactEAddr nvarchar(60) NOT NULL)"
  cmd1.Connection = cnn1

  'Invoke the command 
  Try
   cnn1.Open()
   cmd1.ExecuteNonQuery()
  Catch ex As Exception
   MessageBox.Show(ex.Message)
  Finally
   cnn1.Close()
  End Try

  'Create a DataTable in a DataSet based on the
  'database NotNetTable table
  das1 = New DataSet
  dap1 = New SqlDataAdapter("SELECT * FROM DotNetTable", cnn1)
  dap1.Fill(das1)

  'Create a CommandBuilder object to automatically
  'ceate InsertCommand, UpdateCommand, and DeleteCommand
  'property values for the dap1 DataAdapter object
  Dim bld1 As SqlCommandBuilder = New SqlCommandBuilder(dap1)

 End Sub

 Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

  'Assign values to a DataRow based on DotNetTable
  Dim drw1 As DataRow = das1.Tables(0).NewRow
  drw1("ContactName") = "Rick Dobson"
  drw1("ContactEAddr") = "rickd@cabinc.net"

  'Add DataRow to first DataTable in das1
  das1.Tables(0).Rows.Add(drw1)

  'Update database table with first DataTable in das1
  dap1.Update(das1, das1.Tables(0).TableName)

  'Fill local table from database after
  'IDENTITY value is inserted
  das1.Tables(0).Clear()
  dap1.Fill(das1)

  'Show values in das1
  DisplayTableValues()


 End Sub

 Friend Sub DisplayTableValues()

  Dim str1 As String = ""
  For Each dtb1 As DataTable In das1.Tables
   str1 += "Rows for " & dtb1.TableName & _
    Microsoft.VisualBasic.StrDup(2, ControlChars.CrLf)
   For Each drw1 As DataRow In das1.Tables(dtb1.TableName).Rows
    For Each dcl1 As DataColumn In das1.Tables(dtb1.TableName).Columns
     str1 += drw1(dcl1.ColumnName).ToString & ", "
    Next
    str1 = Microsoft.VisualBasic.Left(str1, Len(str1) - 2)
    str1 += ControlChars.CrLf
   Next
   str1 += ControlChars.CrLf
  Next dtb1
  MessageBox.Show(str1)

 End Sub

 Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

  'Refresh DataTable from database table
  das1.Tables(0).Clear()
  dap1.Fill(das1, das1.Tables(0).TableName)

  'Modify column value in DataTable
  Dim intLast As Integer = das1.Tables(0).Rows.Count - 1
  das1.Tables(0).Rows(intLast)("ContactName") = "Rickie Dobson"

  'Send change to database
  dap1.Update(das1, das1.Tables(0).TableName)

  'Show results
  DisplayTableValues()

 End Sub

 Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click

  'Refresh DataTable from database table
  das1.Tables(0).Clear()
  dap1.Fill(das1, das1.Tables(0).TableName)

  'Assign values to a DataRow based on DotNetTable
  Dim drw1 As DataRow = das1.Tables(0).NewRow
  drw1("ContactName") = "Virginia Dobson"
  drw1("ContactEAddr") = "virginiad@cabinc.net"

  'Add the row first DataTable in das1
  das1.Tables(0).Rows.Add(drw1)

  'Delete first row of first DataTable in das1
  das1.Tables(0).Rows(0).Delete()

  'Update database with both changes
  dap1.Update(das1, das1.Tables(0).TableName)


  'Re-populate DataTable values from database
  das1.Tables(0).Clear()
  dap1.Fill(das1)

  'Show results
  DisplayTableValues()

 End Sub

 Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click

  'Create a command to drop a table
  Dim cmd1 As New SqlCommand
  cmd1.CommandText = "DROP TABLE DotNetTable2"
  cmd1.Connection = cnn1

  'Invoke the command 
  Try
   cnn1.Open()
   cmd1.ExecuteNonQuery()
  Catch ex As Exception
   MessageBox.Show(ex.Message)
  Finally
   cnn1.Close()
  End Try

  'Create a command to create a table
  'Dim cmd1 As New SqlCommand
  cmd1.CommandText = "CREATE TABLE DotNetTable2 (" & _
    "SalesID int NOT NULL, " & _
    "ContactID int NOT NULL, " & _
    "Amount dec(7,2) NOT NULL," & _
    "CONSTRAINT PK_TwoIDs PRIMARY KEY(SalesID, ContactID))"
  cmd1.Connection = cnn1

  'Invoke the command 
  Try
   cnn1.Open()
   cmd1.ExecuteNonQuery()
  Catch ex As Exception
   MessageBox.Show(ex.Message)
  Finally
   cnn1.Close()
  End Try

  'Create SqlDataAdapter for DotNetTable2
  dap2 = New SqlDataAdapter("SELECT * FROM DotNetTable2", cnn1)
  dap2.Fill(das1, "Table2")


  'Add rows to DotNetTable and DotNetTable2
  InsertWithSQL()

 End Sub

 Sub InsertWithSQL()


  'Specify INSERT statement for DotNetTable
  Dim cmd1 As SqlCommand = New SqlCommand
  cmd1.CommandText = "INSERT DotNetTable VALUES(@Name, @EAddr)"
  cmd1.Connection = cnn1

  'Add parameters
  cmd1.Parameters.Add("@Name", SqlDbType.NVarChar, 25).Value = _
   "Rick Dobson"
  cmd1.Parameters.Add("@EAddr", SqlDbType.NVarChar, 60).Value = _
   "rickd@cabinc.net"
  cnn1.Open()

  'Execute insert
  cmd1.ExecuteNonQuery()

  'Assign new parameter values and execute insert again
  cmd1.Parameters("@Name").Value = "Virginia Dobson"
  cmd1.Parameters("@EAddr").Value = "virginiad@cabinc.net"
  cmd1.ExecuteNonQuery()

  cnn1.Close()

  'Fill DotNetTable
  das1.Tables(0).Clear()
  dap1.Fill(das1, das1.Tables(0).TableName)


  'Specify INSERT statement for DotNetTable2
  Dim cmd2 As SqlCommand = New SqlCommand
  cmd2.CommandText = _
   "INSERT DotNetTable2 VALUES(@SalesID, @ContactID, @Amount)"
  cmd2.Connection = cnn1

  'Add parameters
  If das1.Tables(1).Rows.Count = 0 Then
   int1 = 1
   cmd2.Parameters.Add("@SalesID", SqlDbType.Int).Value = int1
  Else
   int1 += 10
   cmd2.Parameters.Add("@SalesID", SqlDbType.Int).Value = int1
  End If
  cmd2.Parameters.Add("@ContactID", SqlDbType.Int).Value = _
   das1.Tables(0).Rows(das1.Tables(0).Rows.Count - 2)("ContactID")
  cmd2.Parameters.Add("@Amount", SqlDbType.Decimal).Value = 75
  cnn1.Open()

  'Execute insert
  cmd2.ExecuteNonQuery()

  'Assign new parameter values
  If das1.Tables(1).Rows.Count = 0 Then
   cmd2.Parameters("@SalesID").Value = 2
   int2 = 2
  Else
   int2 += 10
   cmd2.Parameters("@SalesID").Value = int2
  End If
  cmd2.Parameters("@ContactID").Value = _
   das1.Tables(0).Rows(das1.Tables(0).Rows.Count - 1)("ContactID")
  cmd2.Parameters("@Amount").Value = 26

  'Execute insert
  cmd2.ExecuteNonQuery()

  cnn1.Close()

  'Fill DotNetTable2
  dap2.Fill(das1, das1.Tables(1).TableName)

  DisplayTableValues()

 End Sub

End Class