Imports System.Data.SqlClient
Public Class Form2
  Dim cnn1 As SqlConnection = _
    New System.Data.SqlClient.SqlConnection( _
    "Data Source=.\sqlexpress;" & _
    "Integrated Security=True;" & _
    "Initial Catalog=AdventureWorks")

  Private Sub Form2_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    Me.Height += 50

    Me.GroupBox1.Text = "Get a fixed value"
    Me.GroupBox2.Text = "Get a variable value"
    Me.GroupBox3.Text = "Perform input validation"

    Me.Button1.Width *= 2
    Me.Button1.Text = "Get 1st ProductCategory"
    Me.Button2.Width *= 2
    Me.Button2.Text = "Get Any ProductCategory"
    Me.Button3.Width *= 2
    Me.Button3.Text = "Get Any ProductCategory"

    Me.Label1.Text = ""
    Me.Label2.Text = ""
    Me.Label3.Text = ""

  End Sub

 Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

  Dim cmd1 As New SqlCommand( _
    "SELECT Name FROM Production.ProductCategory Where ProductCategoryID = 1", _
    cnn1)

  cnn1.Open()
  Dim str1 As String = cmd1.ExecuteScalar.ToString
  Me.Label1.Text = str1

  cnn1.Close()

 End Sub

 Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

  Dim str1 As String = Me.TextBox1.Text

  Dim cmd1 As New SqlCommand( _
    "SELECT Name FROM Production.ProductCategory Where ProductCategoryID = " & _
    str1, cnn1)

  cnn1.Open()
  str1 = cmd1.ExecuteScalar.ToString
  Me.Label2.Text = str1

  cnn1.Close()

 End Sub

 Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click

  Dim str1 As String = Me.TextBox2.Text
  Dim int1 As Integer

  'Verify that an integer value is input
  Try
   int1 = CInt(str1)
  Catch ex As Exception
   MessageBox.Show("Please input an integer as a ProductCategoryID value.")
   Exit Sub
  End Try

  Dim strReturn As String = _
    InColRange(str1, "ProductCategoryID", _
    "Production.ProductCategory", cnn1)

  Select Case strReturn
   Case "Value in range"
    'Define cmd1 and execute it
    Dim cmd1 As New SqlCommand( _
      "SELECT Name FROM Production.ProductCategory Where ProductCategoryID = " & _
      str1, cnn1)
    Try
     str1 = cmd1.ExecuteScalar.ToString
     Me.Label3.Text = str1
    Catch ex As Exception
     MessageBox.Show(ex.Message)
    Finally
     cnn1.Close()
    End Try
   Case "Value out of range"
    MessageBox.Show("Enter another ProductCategoryID value.")
   Case Else
    MessageBox.Show(strReturn)
  End Select

 End Sub

 Friend Function InColRange(ByVal strValue As String, _
  ByVal ColName As String, _
  ByVal TabName As String, _
  ByVal cnn1 As SqlConnection) As String

  'Verify value is between min and msx column values
  Try
   Dim strMin As String = "SELECT MIN(" & ColName & ") " & _
    "FROM " & TabName
   Dim cmdMin As New SqlCommand(strMin, cnn1)
   Dim strMax As String = "SELECT MAX(" & ColName & ") " & _
    "FROM " & TabName
   Dim cmdMax As New SqlCommand(strMax, cnn1)
   cnn1.Open()
   Dim intMin As Integer = CInt(cmdMin.ExecuteScalar)
   Dim intMax As Integer = CInt(cmdMax.ExecuteScalar)
   If (CInt(strValue) < intMin Or CInt(strValue) > intMax) Then
    cnn1.Close()
    Return ("Value out of range")
   End If
  Catch ex As Exception
   cnn1.Close()
   Return (ex.Message)
  End Try
  Return ("Value in range")

 End Function

  
End Class