Imports System.Data
Imports System.Data.SqlClient
Public Class Form6
 Dim cnn1 As SqlConnection = _
   New System.Data.SqlClient.SqlConnection( _
   "Data Source=.\sqlexpress;" & _
   "Integrated Security=True;" & _
   "Initial Catalog=AdventureWorks")

 Dim das1 As DataSet
 Dim vew0Name As DataView
 Dim vew0ProductCategoryID As DataView
 Dim vewFiltered As DataView

 Private Sub Form6_Load(ByVal sender As Object, _
  ByVal e As System.EventArgs) Handles Me.Load

  'Create the das1 DataSet with the ProductCategories
  'and ProductSubcategories DataTables
  Dim strQuery1 As String = _
   "SELECT ProductCategoryID, Name " & _
   "FROM Production.ProductCategory"
  Dim strQuery2 As String = _
   "SELECT ProductCategoryID, " & _
   "ProductSubcategoryID, Name " & _
   "FROM Production.ProductSubcategory"

  das1 = Form5.TwoDTsInADS(strQuery1, strQuery2)

  'Define two different views for the first
  'DataTable in the das1 DataSet
  vew0Name = New DataView(das1.Tables(0))
  vew0Name.Sort = "Name"

  vew0ProductCategoryID = New DataView(das1.Tables(0))
  vew0ProductCategoryID.Sort = "ProductCategoryID"

  'Instantiate a view for filtering data from the
  'second DataTable in das1; the filtering criteria
  'are defined dynamically in Button4_Click
  vewFiltered = New DataView(das1.Tables(1))

  'Format Form6 and its controls
  Me.DataGridView1.Width = CInt(Me.DataGridView1.Width * 1.05)
  Me.Height = CInt(1.4 * Me.Height)

  Me.Button1.Text = "Enumerate values"
  Me.Button1.Width = CInt(1.5 * Me.Button1.Width)

  Me.Button2.Text = "Sort by name"
  Me.Button3.Text = "Sort by ID"
  Me.Button2.Width = CInt(1.05 * Me.Button2.Width)

  Me.Button4.Text = "Populate listboxes"
  Me.Button4.Width = CInt(1.5 * Me.Button4.Width)

 End Sub

 Private Sub Button1_Click(ByVal sender As System.Object, _
  ByVal e As System.EventArgs) Handles Button1.Click

  PrintView(vew0Name, 0, _
 "ProductCategory by Name")

  PrintView(vew0ProductCategoryID, 0, _
   "ProductCategory by ProductCategoryID")

 End Sub

 Sub PrintView(ByVal vew As DataView, _
 ByVal tabindx As Integer, _
 ByVal RepTitle As String)


  Dim str1 As String = RepTitle & StrDup(2, ControlChars.CrLf)

  For int1 As Integer = 0 To vew.Count - 1
   For int2 As Integer = 0 To das1.Tables(tabindx).Columns.Count - 1
    str1 += vew(int1)(int2).ToString & ", "
   Next
   str1 = Microsoft.VisualBasic.Left(str1, Len(str1) - 2)
   str1 += ControlChars.CrLf
  Next

  MsgBox(str1)

 End Sub

 Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

  Me.DataGridView1.DataSource = vew0Name

 End Sub

 Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click

  Me.DataGridView1.DataSource = vew0ProductCategoryID

 End Sub

 Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click

  Me.ListBox1.DataSource = vew0Name
  Me.ListBox1.DisplayMember = "Name"

 End Sub

 Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged

  'Specify a filter based on the currently selected item
  'in ListBox1
  vewFiltered.RowFilter = _
   "ProductCategoryID = " & _
   vew0Name(CInt(Me.ListBox1.SelectedIndex)) _
   ("ProductCategoryID").ToString

  'Assign the filtered view as the source for ListBox2
  Me.ListBox2.DataSource = vewFiltered
  Me.ListBox2.DisplayMember = "Name"

 End Sub
End Class