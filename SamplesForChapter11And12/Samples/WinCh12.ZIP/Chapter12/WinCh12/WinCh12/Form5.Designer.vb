<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class Form5
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
  Me.ListBox2 = New System.Windows.Forms.ListBox
  Me.ListBox1 = New System.Windows.Forms.ListBox
  Me.Button3 = New System.Windows.Forms.Button
  Me.RadioButton2 = New System.Windows.Forms.RadioButton
  Me.Button2 = New System.Windows.Forms.Button
  Me.GroupBox1 = New System.Windows.Forms.GroupBox
  Me.RadioButton1 = New System.Windows.Forms.RadioButton
  Me.Button1 = New System.Windows.Forms.Button
  Me.GroupBox1.SuspendLayout()
  Me.SuspendLayout()
  '
  'ListBox2
  '
  Me.ListBox2.FormattingEnabled = True
  Me.ListBox2.Location = New System.Drawing.Point(159, 175)
  Me.ListBox2.Name = "ListBox2"
  Me.ListBox2.Size = New System.Drawing.Size(120, 95)
  Me.ListBox2.TabIndex = 10
  '
  'ListBox1
  '
  Me.ListBox1.FormattingEnabled = True
  Me.ListBox1.Location = New System.Drawing.Point(13, 175)
  Me.ListBox1.Name = "ListBox1"
  Me.ListBox1.Size = New System.Drawing.Size(120, 95)
  Me.ListBox1.TabIndex = 9
  '
  'Button3
  '
  Me.Button3.Location = New System.Drawing.Point(13, 145)
  Me.Button3.Name = "Button3"
  Me.Button3.Size = New System.Drawing.Size(75, 23)
  Me.Button3.TabIndex = 8
  Me.Button3.Text = "Button3"
  '
  'RadioButton2
  '
  Me.RadioButton2.AutoSize = True
  Me.RadioButton2.Location = New System.Drawing.Point(107, 33)
  Me.RadioButton2.Name = "RadioButton2"
  Me.RadioButton2.Size = New System.Drawing.Size(86, 17)
  Me.RadioButton2.TabIndex = 1
  Me.RadioButton2.Text = "RadioButton2"
  '
  'Button2
  '
  Me.Button2.Location = New System.Drawing.Point(7, 66)
  Me.Button2.Name = "Button2"
  Me.Button2.Size = New System.Drawing.Size(75, 23)
  Me.Button2.TabIndex = 1
  Me.Button2.Text = "Button2"
  '
  'GroupBox1
  '
  Me.GroupBox1.Controls.Add(Me.RadioButton2)
  Me.GroupBox1.Controls.Add(Me.Button2)
  Me.GroupBox1.Controls.Add(Me.RadioButton1)
  Me.GroupBox1.Location = New System.Drawing.Point(13, 38)
  Me.GroupBox1.Name = "GroupBox1"
  Me.GroupBox1.Size = New System.Drawing.Size(200, 100)
  Me.GroupBox1.TabIndex = 7
  Me.GroupBox1.TabStop = False
  Me.GroupBox1.Text = "GroupBox1"
  '
  'RadioButton1
  '
  Me.RadioButton1.AutoSize = True
  Me.RadioButton1.Location = New System.Drawing.Point(7, 33)
  Me.RadioButton1.Name = "RadioButton1"
  Me.RadioButton1.Size = New System.Drawing.Size(86, 17)
  Me.RadioButton1.TabIndex = 0
  Me.RadioButton1.Text = "RadioButton1"
  '
  'Button1
  '
  Me.Button1.Location = New System.Drawing.Point(13, 8)
  Me.Button1.Name = "Button1"
  Me.Button1.Size = New System.Drawing.Size(75, 23)
  Me.Button1.TabIndex = 6
  Me.Button1.Text = "Button1"
  '
  'Form5
  '
  Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
  Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
  Me.ClientSize = New System.Drawing.Size(292, 266)
  Me.Controls.Add(Me.ListBox2)
  Me.Controls.Add(Me.ListBox1)
  Me.Controls.Add(Me.Button3)
  Me.Controls.Add(Me.GroupBox1)
  Me.Controls.Add(Me.Button1)
  Me.Name = "Form5"
  Me.Text = "Form5"
  Me.GroupBox1.ResumeLayout(False)
  Me.GroupBox1.PerformLayout()
  Me.ResumeLayout(False)

 End Sub
 Friend WithEvents ListBox2 As System.Windows.Forms.ListBox
 Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
 Friend WithEvents Button3 As System.Windows.Forms.Button
 Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
 Friend WithEvents Button2 As System.Windows.Forms.Button
 Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
 Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
 Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
