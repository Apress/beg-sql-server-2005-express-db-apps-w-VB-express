Imports System.Data
Imports System.Data.SqlClient
Public Class Form8
 Dim cnn1 As SqlConnection = _
   New System.Data.SqlClient.SqlConnection( _
   "Data Source=.\sqlexpress;" & _
   "Integrated Security=True;" & _
   "Initial Catalog=AdventureWorks")

 Dim dap1 As SqlClient.SqlDataAdapter
 Dim das1 As DataSet

 Private Sub Form8_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

  MakeDotNetTable()
  AddThreeRows()

  'Add DataBindings to TextBox controls
  Me.TextBox1.DataBindings.Add( _
   "Text", das1, "Table.ContactID")
  Me.TextBox2.DataBindings.Add( _
   "Text", das1, "Table.ContactName")
  Me.TextBox3.DataBindings.Add( _
   "Text", das1, "Table.ContactEAddr")

  Me.TextBox1.ReadOnly = True
  Me.TextBox2.ReadOnly = True
  Me.TextBox3.ReadOnly = True

  Me.TextBox1.Width += 10
  Me.TextBox2.Width += 10
  Me.TextBox3.Width += 10

  Me.Button1.Text = "Last"
  Me.Button2.Text = "Next"
  Me.Button3.Text = "Previous"
  Me.Button4.Text = "First"

  Me.Label1.Text = "ContactID:"
  Me.Label2.Text = "ContactName:"
  Me.Label3.Text = "ContactEAddr:"

 End Sub

 Private Sub Button1_Click(ByVal sender As System.Object, _
  ByVal e As System.EventArgs) Handles Button1.Click
  Me.BindingContext( _
   das1, das1.Tables(0).TableName).Position = _
   das1.Tables(0).Rows.Count - 1
 End Sub

 Private Sub Button2_Click(ByVal sender As System.Object, _
  ByVal e As System.EventArgs) Handles Button2.Click
  Me.BindingContext( _
   das1, das1.Tables(0).TableName).Position += 1
 End Sub

 Private Sub Button3_Click(ByVal sender As System.Object, _
  ByVal e As System.EventArgs) Handles Button3.Click
  Me.BindingContext( _
   das1, das1.Tables(0).TableName).Position -= 1
 End Sub

 Private Sub Button4_Click(ByVal sender As System.Object, _
  ByVal e As System.EventArgs) Handles Button4.Click
  Me.BindingContext( _
   das1, das1.Tables(0).TableName).Position = 0
 End Sub

 Sub MakeDotNetTable()

  'Create a command to drop a table
  Dim cmd1 As New SqlCommand
  cmd1.CommandText = "DROP TABLE DotNetTable"
  cmd1.Connection = cnn1

  'Invoke the command 
  Try
   cnn1.Open()
   cmd1.ExecuteNonQuery()
  Catch ex As Exception
   MessageBox.Show(ex.Message)
  Finally
   cnn1.Close()
  End Try

  'Create a command to create a table
  'Dim cmd1 As New SqlCommand
  cmd1.CommandText = "CREATE TABLE DotNetTable (" & _
    "ContactID int IDENTITY PRIMARY KEY, " & _
    "ContactName nvarchar(25) NOT NULL, " & _
    "ContactEAddr nvarchar(60) NOT NULL)"
  cmd1.Connection = cnn1

  'Invoke the command 
  Try
   cnn1.Open()
   cmd1.ExecuteNonQuery()
  Catch ex As Exception
   MessageBox.Show(ex.Message)
  Finally
   cnn1.Close()
  End Try

  'Make DataTable matching database table
  das1 = New DataSet
  dap1 = New SqlDataAdapter("SELECT * FROM DotNetTable", cnn1)
  dap1.Fill(das1)
  Dim bld1 As SqlCommandBuilder = New SqlCommandBuilder(dap1)

 End Sub

 Sub AddThreeRows()

  Dim drw1 As DataRow = das1.Tables(0).NewRow
  drw1("ContactName") = "Rick Dobson"
  drw1("ContactEAddr") = "rickd@cabinc.net"
  das1.Tables(0).Rows.Add(drw1)

  drw1 = das1.Tables(0).NewRow
  drw1("ContactName") = "Virginia Dobson"
  drw1("ContactEAddr") = "virginiad@cabinc.net"
  das1.Tables(0).Rows.Add(drw1)

  drw1 = das1.Tables(0).NewRow
  drw1("ContactName") = "Tony Hill"
  drw1("ContactEAddr") = "tonyh@cabinc.net"
  das1.Tables(0).Rows.Add(drw1)

  dap1.Update(das1, das1.Tables(0).TableName)

  das1.Tables(0).Clear()
  dap1.Fill(das1)

 End Sub

End Class