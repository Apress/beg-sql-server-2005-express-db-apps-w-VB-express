Imports System.Data.SqlClient
Public Class Form3
  Dim cnn1 As SqlConnection = _
    New System.Data.SqlClient.SqlConnection( _
    "Data Source=.\sqlexpress;" & _
    "Integrated Security=True;" & _
    "Initial Catalog=AdventureWorks")
 Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

  'Create SqlDataReader for two columns from the 
  'ProductCategory table
  Dim strQuery As String = "SELECT ProductCategoryID, Name " & _
   "FROM Production.ProductCategory " & _
   "ORDER BY ProductCategoryID"
  Dim cmd1 As New SqlCommand(strQuery, cnn1)
  cnn1.Open()
  Dim rdr1 As SqlDataReader
  rdr1 = cmd1.ExecuteReader()

  'Read through rows in data source
  Dim str1 As String = ""
  Try
   While rdr1.Read()
    str1 += rdr1.GetSqlInt32(0).ToString _
     & ", " & _
     rdr1.GetSqlString(rdr1.GetOrdinal("Name")).ToString & _
     ControlChars.CrLf
   End While
  Catch ex As Exception
   MessageBox.Show(ex.Message)
  Finally
   rdr1.Close()
   cnn1.Close()
  End Try

  'Display values from SqlDataReader
  MessageBox.Show( _
   Microsoft.VisualBasic.Left(str1, str1.Length - 2), _
   "Product Categories")

 End Sub

 Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

  'Create SqlDataReader for two result sets
  Dim strQuery As String = "SELECT ProductCategoryID, Name " & _
    "FROM Production.ProductCategory " & _
    "ORDER BY ProductCategoryID;" & _
    "SELECT ProductSubcategoryID, Name " & _
    "FROM Production.ProductSubcategory " & _
    "ORDER BY ProductCategoryID, ProductSubcategoryID"
  Dim cmd1 As New SqlCommand(strQuery, cnn1)
  cnn1.Open()
  Dim rdr1 As SqlDataReader
  rdr1 = cmd1.ExecuteReader()

  'Read through and label each result set
  Dim str1 As String = "Product Categories" & ControlChars.CrLf
  Dim bolSecondRSStarted As Boolean
  Try
   Do
    Do While rdr1.Read()
     str1 += rdr1.GetSqlInt32(0).ToString & _
      ", " & _
      rdr1.GetString(1) & _
      ControlChars.CrLf
    Loop
    If bolSecondRSStarted = False Then
     str1 += ControlChars.CrLf & "Product Subcategories" & ControlChars.CrLf
     bolSecondRSStarted = True
    End If
   Loop While rdr1.NextResult
  Catch ex As Exception
   MessageBox.Show(ex.Message)
  Finally
   rdr1.Close()
   cnn1.Close()
  End Try

  'Display values from SqlDataReader
  MessageBox.Show( _
   Microsoft.VisualBasic.Left(str1, str1.Length - 2), _
   "Product Categories followed by Product Subcategories")

 End Sub

 Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click

  'Create SqlDataReader for two columns from the 
  'ProductCategory table
  Dim strQuery As String = "SELECT ProductCategoryID, Name " & _
   "FROM Production.ProductCategory " & _
   "ORDER BY ProductCategoryID"
  Dim cmd1 As New SqlCommand(strQuery, cnn1)
  cnn1.Open()
  Dim rdr1 As SqlDataReader
  rdr1 = cmd1.ExecuteReader()

  'Read through rows in data source and populate ListBox1
  Try
   Me.ListBox1.Items.Clear()
   While rdr1.Read()
    Me.ListBox1.Items.Add(rdr1.GetString(1))
   End While
   Me.ListBox1.Height = 65
  Catch ex As Exception
   MessageBox.Show(ex.Message)
  Finally
   rdr1.Close()
   cnn1.Close()
  End Try



 End Sub
End Class