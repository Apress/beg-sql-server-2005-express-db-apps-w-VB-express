Imports System.Data.OleDb
Imports System.Data.SqlClient
Partial Class _Default
 Inherits System.Web.UI.Page

 Protected Sub form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles form1.Load
  If Not Me.IsPostBack Then
   Me.Title = "Connect/query local databases"
   Me.Button1.Text = "Query Access"
   Me.Button2.Text = "Query SQL Server"
   Me.Button1.Width = 125
   Me.Button2.Width = 125
   Me.Label1.Text = ""
  End If
 End Sub

 Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click

  Dim cnn1 As New OleDbConnection
  Dim cmd1 As New OleDbCommand

  'Compute path to and create connection for Access database file
  Dim DSPath As String = _
      My.Computer.FileSystem.CombinePath( _
      Server.MapPath("/WebCh12/App_Data"), "Northwind.mdb")
  cnn1.ConnectionString = "Provider = Microsoft.Jet.OLEDB.4.0;" & _
    "Data Source = " & DSPath

  'Open connection, use it, close it
  Try
   cnn1.Open()
   cmd1.CommandText = "SELECT Count(*) FROM Shippers"
   cmd1.Connection = cnn1
   Me.Label1.Text = "Number of Shippers: " & _
    cmd1.ExecuteScalar().ToString
  Catch ex As Exception
   My.Response.Write(ex.Message)
  Finally
   cnn1.Close()
   My.Response.Write("Connection closed.")
  End Try

 End Sub

 Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click

  Dim cnn1 As New SqlConnection
  Dim cmd1 As New SqlCommand

  'Compute top-level project folder and use it as a prefix for
  'the primary data file in the connection string for cnn1
  Dim pdbfph As String = _
      My.Computer.FileSystem.CombinePath( _
      Server.MapPath("/WebCh12/App_Data"), "Northwnd.mdf")
  Dim cst As String = "Data Source=.\sqlexpress;" & _
    "Integrated Security=SSPI;" & _
    "AttachDBFileName=" & pdbfph
  cnn1.ConnectionString = cst


  Try
   cnn1.Open()
   cmd1.CommandText = "SELECT Count(*) FROM Shippers"
   cmd1.Connection = cnn1
   Me.Label1.Text = "Number of Shippers: " & _
    cmd1.ExecuteScalar().ToString
  Catch ex As Exception
   My.Response.Write(ex.Message)
  Finally
   cnn1.Close()
   My.Response.Write("Connection closed.")
  End Try

 End Sub
End Class
